package com.restaurant.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.restaurant.Model.RestaurantEntity;
import com.restaurant.Repo.RestaurantRepository;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class DBManagementService implements DBManagementServiceIF{
	@Autowired
	private RestaurantRepository restRepo;



	@Override
	public List<RestaurantEntity> findAllRestaurantsSS(String restName, String location, String uisine) {
		return restRepo.findAllRestaurantsSS(restName,  location, uisine);
	}

	@Override
	public Optional<RestaurantEntity> findRestaurant(long restaurantId) {
	  return restRepo.findById(restaurantId);
		
	}
	

}
