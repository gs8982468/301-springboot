
package com.restaurant.Repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.restaurant.Model.RestaurantEntity;

@Repository
public interface RestaurantRepository extends JpaRepository<RestaurantEntity, Long> {
	
	
	
	@Query(value = "select * from RESTAURANTS", nativeQuery=true)
	public List<RestaurantEntity> findAllRestaurants();
	
	@Query(value = "select * from RESTAURANTS where (?1 IS NULL OR RESTAURANT_NAME=?1) AND (?2 IS NULL OR LOCATION=?2) AND (?3 IS NULL OR CUISINE=?3)", nativeQuery=true)
	public List<RestaurantEntity> findAllRestaurantsSS(String restaurantName, String location, String cuisine);
	
}
