package com.restaurant.Service;

import java.util.List;
import java.util.Optional;

import org.hibernate.service.spi.ServiceException;
import org.springframework.stereotype.Component;

import com.restaurant.DTO.RestaurantRequestDto;
import com.restaurant.Model.RestaurantEntity;

@Component
public interface RstaurantApplicationIf {

	/**
	 * This method is used to place an order
	 * @param orderRequestDto OrderRequestDto
	 */
	List<RestaurantEntity> findAllRestaurants(RestaurantRequestDto restaurantSearchRequest) throws ServiceException;

	Optional<RestaurantEntity> findRestaurentbyRestaurantID(long restaurantId);
	

	
}
