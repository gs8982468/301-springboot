package com.restaurant.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "MENU_ITEM")
//@Getter @Setter @NoArgsConstructor
public class MenuItemEntity {
	
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	@Column(name = "MENU_ID")
	@JsonProperty("Menu id")
	private Long menuId;
	
	@Column(name = "FOOD_NAME")
	@JsonProperty("Food name")
	private String foodName;
	
	@Column(name = "PRICE")
	@JsonProperty("Price")
	private int price;
	
	@Column(name = "IS_AVAILABLE")
	@JsonProperty("Is available")
	private boolean isAvailable;
	
	@ManyToOne
	@JoinColumn(name= "RESTAURENT_ID")
	private RestaurantEntity rest;
	
	
	public Long getMenuId() {
		return menuId;
	}



	public void setMenuId(Long menuId) {
		this.menuId = menuId;
	}



	public String getFoodName() {
		return foodName;
	}



	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}



	public int getPrice() {
		return price;
	}



	public void setPrice(int price) {
		this.price = price;
	}



	public boolean isAvailable() {
		return isAvailable;
	}



	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}





	public MenuItemEntity(String foodName,int price, boolean isAvailable) {
		this.foodName = foodName;
		this.isAvailable = isAvailable;
		this.price = price;
	}



	public MenuItemEntity() {
		super();
		// TODO Auto-generated constructor stub
	}


	@Override
	public String toString() {
		return "MenuItem [id=" + menuId + ", name=" + foodName + ", price=" + price +  "]";
	}
	

}
