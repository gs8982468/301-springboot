package com.restaurant.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Component;

import com.restaurant.Model.RestaurantEntity;
@Component
public interface DBManagementServiceIF {

	

	public List<RestaurantEntity>  findAllRestaurantsSS(String restName, String location, String uisine);


	public Optional<RestaurantEntity> findRestaurant(long restaurantId);

	
}
