package com.restaurant.DTO;
public class RestaurantRequestDto {
	
	private String restaurantName;
	private String location;
	private String cuisine;
	private String budget;
	
	/*public RestaurantRequestDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public RestaurantRequestDto(String name, String location, String cuisine, String budget) {
		super();
		this.restaurantName = name;
		this.location = location;
		this.cuisine = cuisine;
		this.budget = budget;
	
	}
	@Override
	public String toString() {
		return "RestaurantRequestDto [name=" + restaurantName + ", location=" + location + ", cuisine=" + cuisine + ", budget="
				+ budget;
	}*/
	
	public String getLocation() {
		return location;
	}
	public String getRestaurantName() {
		return restaurantName;
	}
	public void setRestaurantName(String restaurantName) {
		this.restaurantName = restaurantName;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getCuisine() {
		return cuisine;
	}
	public void setCuisine(String cuisine) {
		this.cuisine = cuisine;
	}
	public String getBudget() {
		return budget;
	}
	public void setBudget(String budget) {
		this.budget = budget;
	}
	
	

	
}
