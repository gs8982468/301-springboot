package com.restaurant.DTO;

import java.util.List;

import com.restaurant.Model.RestaurantEntity;

//@Getter @Setter @NoArgsConstructor
public class RestaurantResponseDto {
	
	List<RestaurantEntity> restaurants;
	int totalPages;
	long totalElements;

	public RestaurantResponseDto(List<RestaurantEntity> restaurants, int totalPages, long totalElements) {
		super();
		this.restaurants = restaurants;
		this.totalPages = totalPages;
		this.totalElements = totalElements;
	}

	public List<RestaurantEntity> getRestaurants() {
		return restaurants;
	}

	public void setRestaurants(List<RestaurantEntity> restaurants) {
		this.restaurants = restaurants;
	}

	public int getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public long getTotalElements() {
		return totalElements;
	}

	public void setTotalElements(long totalElements) {
		this.totalElements = totalElements;
	}


}
