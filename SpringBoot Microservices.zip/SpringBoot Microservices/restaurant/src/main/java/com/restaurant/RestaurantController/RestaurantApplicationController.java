package com.restaurant.RestaurantController;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.restaurant.AuthService.JwtAuthenticationService;
import com.restaurant.DTO.RestaurantRequestDto;
import com.restaurant.DTO.UserDto;
import com.restaurant.Exception.UnauthorizedException;
import com.restaurant.Model.RestaurantEntity;
import com.restaurant.Repo.RestaurantRepository;

@RestController
public class RestaurantApplicationController {
	
	private static final Logger logger = LoggerFactory.getLogger(RestaurantApplicationController.class);

	@Autowired
	private RestaurantRepository restRepo;
	
	@Autowired
	JwtAuthenticationService authenticationService;

	@RequestMapping(value="/home", method= RequestMethod.GET)
	public String check(){
		return "Hi User";
	}
	
	
	@RequestMapping(value="/login", method= RequestMethod.POST)
	public ResponseEntity<String> enroll(@RequestBody UserDto user) throws UnauthorizedException  {
		logger.debug("Calling authentication service to verify user");
		String token = authenticationService.authenticateUser(user);
		logger.debug("User verified, returning back token");	 
		return ResponseEntity
				.status(HttpStatus.OK)
				.body(token);

	}
	
	@RequestMapping(value="/findRestaurants", method= RequestMethod.POST)
	public ResponseEntity<List<RestaurantEntity>> findAllRestaurants(@RequestHeader String authorization, @RequestBody RestaurantRequestDto restaurantSearchRequest){
		//List<RestaurantEntity> reList = !CollectionUtils.isEmpty(restRepo.findAllRestaurants()) ? restRepo.findAllRestaurants() : null;
		
		//restaurantSearchRequest.setName("Ali baba");
		//restaurantSearchRequest.setLocation("Bagnan");
		//restaurantSearchRequest.setCuisine("kkk");
		List<RestaurantEntity> reList = !CollectionUtils
				.isEmpty(restRepo.findAllRestaurantsSS(restaurantSearchRequest.getRestaurantName(),
						restaurantSearchRequest.getLocation(), restaurantSearchRequest.getCuisine()))
								? restRepo.findAllRestaurantsSS(restaurantSearchRequest.getRestaurantName(),
										restaurantSearchRequest.getLocation(), restaurantSearchRequest.getCuisine())
								: null;
		
		if(null != restaurantSearchRequest.getRestaurantName() && null != restaurantSearchRequest.getBudget() && null != restaurantSearchRequest.getCuisine() && null != restaurantSearchRequest.getLocation()){
			
			
		}
		
		
		
		return ResponseEntity
				.status(HttpStatus.OK)
				.body(reList);
	}

}
