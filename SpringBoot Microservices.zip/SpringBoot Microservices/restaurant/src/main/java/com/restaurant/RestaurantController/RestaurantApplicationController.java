package com.restaurant.RestaurantController;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.restaurant.AuthService.JwtAuthenticationService;
import com.restaurant.DTO.RestaurantRequestDto;
import com.restaurant.DTO.UserDto;
import com.restaurant.Exception.UnauthorizedException;
import com.restaurant.Model.RestaurantEntity;
import com.restaurant.Repo.RestaurantRepository;
import com.restaurant.Service.RstaurantApplicationIf;

@RestController
public class RestaurantApplicationController {
	
	private static final Logger logger = LoggerFactory.getLogger(RestaurantApplicationController.class);

	@Autowired
	private RestaurantRepository restRepo;
	
	@Autowired
	private RstaurantApplicationIf restaurantApplicationIf;
	
	@Autowired
	JwtAuthenticationService authenticationService;

	@RequestMapping(value="/home", method= RequestMethod.GET)
	public String check(){
		return "Hi User, Welcome to Restaurant service";
	}
	
	
	@RequestMapping(value="/login", method= RequestMethod.POST)
	public ResponseEntity<String> enroll(@RequestBody UserDto user) throws UnauthorizedException  {
		logger.debug("Calling authentication service to verify user");
		String token = authenticationService.authenticateUser(user);
		logger.debug("User verified, returning back token");	 
		return ResponseEntity
				.status(HttpStatus.OK)
				.body(token);

	}
	
	@RequestMapping(value="/findRestaurants", method= RequestMethod.POST)
	public ResponseEntity<List<RestaurantEntity>> findAllRestaurants(@RequestHeader String authorization, @RequestBody RestaurantRequestDto restaurantSearchRequest){
		List<RestaurantEntity> reList = restaurantApplicationIf.findAllRestaurants(restaurantSearchRequest);
		
		return ResponseEntity
				.status(HttpStatus.OK)
				.body(reList);
	}
	
	@RequestMapping(value="/find/restaurantts/{restaurantId}", method= RequestMethod.GET)
	public ResponseEntity<RestaurantEntity> fetchRestetails(@PathVariable long restaurantId){
		Optional<RestaurantEntity> reList = restaurantApplicationIf.findRestaurentbyRestaurantID(restaurantId);
				
		return ResponseEntity
				.status(HttpStatus.OK)
				.body(reList.get());
	}
	
	

}
