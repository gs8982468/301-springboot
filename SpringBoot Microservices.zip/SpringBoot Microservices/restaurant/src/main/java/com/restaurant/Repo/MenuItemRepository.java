package com.restaurant.Repo;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.restaurant.Model.MenuItemEntity;

@Repository
public interface MenuItemRepository extends JpaRepository<MenuItemEntity, Long> {
	
	/*Page<MenuItemEntity> findByNameContaining(String name, Pageable pageable);
	
	Optional<MenuItemEntity> findById(Long id);
	Page<MenuItemEntity> findByMenu_id(Long id, Pageable pageable);*/

}
