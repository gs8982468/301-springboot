package com.restaurant.Exception;

public class ItemNotFoundException extends Exception {
	
	
	public ItemNotFoundException() {
		super();
	}
	public ItemNotFoundException(String msg) {
		super(msg);
	}

}
