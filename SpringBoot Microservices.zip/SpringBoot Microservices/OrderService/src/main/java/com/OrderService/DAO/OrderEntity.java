package com.OrderService.DAO;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name= "ORDERS")
public class OrderEntity {
	@Id
	@SequenceGenerator(name = "seq_tab", sequenceName="seq_tab", schema= "gs8982468", allocationSize=1)
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="seq_tab")
	@Column(name = "ORDER_ID")
	@JsonProperty("Order Id")
	private Long orderId;
	
	@Column(name = "RESTAURANT_ID")
	@JsonProperty("Restaurant Id")
	private long restaurantId;
	
	@Column(name = "MENU_ID")
	@JsonProperty("Menu Id")
	private long menuId;
	
	@Column(name = "FOOD_NAME")
	@JsonProperty("Food name")
	private String foodName;
	
	@Column(name = "PRICE")
	@JsonProperty("Price")
	private int price;
	
	
	@Column(name = "TOTAL_PRICE")
	@JsonProperty("Total Price")
	private int totalPrice;
	
	
	@Column(name = "QUANTITY")
	@JsonProperty("Quantity")
	private int quantity;
	
	@ManyToOne
	@JoinColumn(name= "USER_ID")
	private UserEntity user;
	
	

	public void setUser(UserEntity user) {
		this.user = user;
	}

	public int getQuantity() {
		return quantity;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public long getRestaurantId() {
		return restaurantId;
	}

	public void setRestaurantId(long restaurantId) {
		this.restaurantId = restaurantId;
	}

	public long getMenuId() {
		return menuId;
	}

	public void setMenuId(long menuId) {
		this.menuId = menuId;
	}

	public String getFoodName() {
		return foodName;
	}

	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	

	public int getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}

	public int isQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	
	

}
