package com.OrderService.Model;

import com.fasterxml.jackson.annotation.JsonProperty;


public class MenuItemDetailsResponseEntity {
	

	@JsonProperty("Menu id")
	private Long menuId;

	@JsonProperty("Food name")
	private String foodName;

	@JsonProperty("Price")
	private int price;
	

	@JsonProperty("Is available")
	private boolean isAvailable;

	
	/*@ManyToOne
	@JoinColumn(name = "menu_id", nullable = false)
	@OnDelete(action = OnDeleteAction.CASCADE)
	Menu menu;*/
	
	
	public Long getMenuId() {
		return menuId;
	}



	public void setMenuId(Long menuId) {
		this.menuId = menuId;
	}



	public String getFoodName() {
		return foodName;
	}



	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}



	public int getPrice() {
		return price;
	}



	public void setPrice(int price) {
		this.price = price;
	}



	public boolean getIsAvailable() {
		return isAvailable;
	}



	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}





	public MenuItemDetailsResponseEntity(String foodName,int price, boolean isAvailable) {
		this.foodName = foodName;
		this.isAvailable = isAvailable;
		this.price = price;
	}



	public MenuItemDetailsResponseEntity() {
		super();
		// TODO Auto-generated constructor stub
	}


	@Override
	public String toString() {
		return "MenuItem [id=" + menuId + ", name=" + foodName + ", price=" + price +  "]";
	}
	

}
