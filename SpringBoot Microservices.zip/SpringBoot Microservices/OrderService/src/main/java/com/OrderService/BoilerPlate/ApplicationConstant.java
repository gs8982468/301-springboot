package com.OrderService.BoilerPlate;

public class ApplicationConstant {
	public String restaurantHost = "http://localhost:8090";

	public ApplicationConstant(String restaurantHost) {
		super();
		//this.restaurantHost = restaurantHost;
	}
	
	
	
}