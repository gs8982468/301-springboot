package com.OrderService.Service;

import java.util.List;

import org.hibernate.service.spi.ServiceException;
import org.springframework.stereotype.Component;

import com.OrderService.DAO.OrderRequestDto;
import com.OrderService.DAO.OrderUpdateDto;
import com.OrderService.DAO.UserEntity;
import com.OrderService.Model.Order;

@Component
public interface OrderManagerIF {

	/**
	 * This method is used to place an order
	 * @param orderRequestDto OrderRequestDto
	 */
	List<Order> placeOrder( OrderRequestDto orderRequestDto) throws ServiceException;
	
	/**
	 * This method is used to view order of user
	 * @param userid long
	 */
	UserEntity viewOrder(long userid) throws ServiceException;

	/**
	 * This method is used to update order of user
	 * @param orderUpdateDto OrderUpdateDto
	 * @throws Exception 
	 */
	String updateOrder(OrderUpdateDto orderUpdateDto) throws ServiceException, Exception;
	
	/**
	 * This method is used to view order of user
	 * @param userid long
	 * @throws Exception 
	 */
	String cancelOrder(long userid) throws ServiceException, Exception; 
	

	
}
