package com.OrderService.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.hibernate.service.spi.ServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import com.OrderService.DAO.OrderEntity;
import com.OrderService.DAO.OrderRequestDto;
import com.OrderService.DAO.OrderUpdateDto;
import com.OrderService.DAO.OrderedItemsDto;
import com.OrderService.DAO.UserEntity;
import com.OrderService.Model.MenuItemDetailsResponseEntity;
import com.OrderService.Model.Order;
import com.OrderService.Model.RestaurantDetailsResponseEntity;
import com.OrderService.Model.Repository.OrderRepository;
import com.OrderService.Model.Repository.UserRepository;

@Service
public class OrdermanagerIMPL implements OrderManagerIF {
	private static final Logger log = LoggerFactory.getLogger(OrdermanagerIMPL.class);
	
	@Autowired
	private DBManagementServiceIF dbManager;


	@Autowired
	private RestTemplate rest;

	@Value("${restaurant.search.item.url}")
	private String restaurantServiceItemUrl;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.OrderService.Service.OrderManagerIF#placeOrder(com.OrderService.DAO.
	 * OrderRequestDto)
	 */
	@Override
	@Transactional
	public List<Order> placeOrder(OrderRequestDto orderRequestDto) throws ServiceException{

		List<Order> orderDetails = new ArrayList<Order>();
		UserEntity userEntity = null;
		try {
			userEntity = dbManager.findUserByUserId(orderRequestDto.getUserId());
		} catch (Exception e) {
			log.info("Error occurred while fetching user data from DB");
		}
		userEntity = createUserEntity(orderRequestDto, userEntity);
		List<OrderEntity> orderEntityList = new ArrayList<>();

		for (OrderedItemsDto items : orderRequestDto.getItems()) {

			saveOrderBasedOnUserEntity(orderDetails, userEntity, orderEntityList, items);
		}
		saveUserDetailsIntoDB(userEntity, orderEntityList);
		return orderDetails;

	}

	private void saveUserDetailsIntoDB(UserEntity userEntity, List<OrderEntity> orderEntityList) {
		userEntity.setOrderEntity(orderEntityList);

		int totalPriceToBePaid = 0;
		if (!CollectionUtils.isEmpty(userEntity.getOrderEntity())) {
			for (OrderEntity order : userEntity.getOrderEntity()) {
				totalPriceToBePaid = totalPriceToBePaid + order.getTotalPrice();
			}
		} else {
			totalPriceToBePaid = userEntity.getTotalPriceToBePaid();
		}

		userEntity.setTotalPriceToBePaid(totalPriceToBePaid);

		dbManager.updateUserDetails(userEntity);
	}

	private void saveOrderBasedOnUserEntity(List<Order> orderDetails, UserEntity userEntity,
			List<OrderEntity> orderEntityList, OrderedItemsDto items) {
		StringBuilder restaurantSearchURL = new StringBuilder(restaurantServiceItemUrl);
		restaurantSearchURL.append("/" + "find/restaurantts/");
		restaurantSearchURL.append(items.getRestaurantId());

		ResponseEntity<RestaurantDetailsResponseEntity> fetchRestaurantDetails = rest
				.exchange(restaurantSearchURL.toString(), HttpMethod.GET, null, RestaurantDetailsResponseEntity.class);
		if (null != fetchRestaurantDetails.getBody()
				&& !CollectionUtils.isEmpty(fetchRestaurantDetails.getBody().getMenuDetails())) {

			Optional<MenuItemDetailsResponseEntity> findmenuDetails = fetchRestaurantDetails.getBody().getMenuDetails()
					.stream().filter(md -> md.getMenuId() == items.getMenuId()).findAny();

			Optional<OrderEntity> oeOptional = Optional.empty();

			if (!CollectionUtils.isEmpty(userEntity.getOrderEntity())) {
				oeOptional = userEntity.getOrderEntity().stream().filter(oe -> oe.getMenuId() == items.getMenuId())
						.findAny();
			}

			if (null != findmenuDetails.get() && !oeOptional.isPresent()) {
				saveOrder(orderDetails, userEntity, orderEntityList, items, findmenuDetails);

			} else {
				Order orderResponse = new Order();
				orderResponse.setMenId(items.getMenuId());
				orderResponse.setStatus("You have already ordered this item. Please Try update-order service to updat yor order");
				orderDetails.add(orderResponse);
			}

		} else {
			Order orderResponse = new Order();
			orderResponse.setMenId(items.getMenuId());
			orderResponse.setStatus("Restaurant noit aailable");
			orderDetails.add(orderResponse);
		}
	}

	private void saveOrder(List<Order> orderDetails, UserEntity userEntity, List<OrderEntity> orderEntityList,
			OrderedItemsDto items, Optional<MenuItemDetailsResponseEntity> findmenuDetails) {
		if (findmenuDetails.get().getIsAvailable()) {
			OrderEntity order = new OrderEntity();
			order.setUser(userEntity);
			order.setFoodName(findmenuDetails.get().getFoodName());
			order.setPrice(findmenuDetails.get().getPrice());
			order.setQuantity(items.getQuantity());
			order.setTotalPrice(items.getQuantity() * findmenuDetails.get().getPrice());
			order.setMenuId(items.getMenuId());
			order.setRestaurantId(items.getRestaurantId());
			orderEntityList.add(order);
			userEntity.setItemOrdred("Yes");

			Order orderResponse = new Order();
			orderResponse.setMenId(items.getMenuId());
			orderResponse.setStatus("Order successfull");
			orderDetails.add(orderResponse);
		} else {
			Order orderResponse = new Order();
			orderResponse.setMenId(items.getMenuId());
			orderResponse.setStatus("This Item not available at theis moment");
			orderDetails.add(orderResponse);
		}
	}

	private UserEntity createUserEntity(OrderRequestDto orderRequestDto, UserEntity userEntity) {
		if (null == userEntity) {
			userEntity = new UserEntity();
			userEntity.setUserId(orderRequestDto.getUserId());
			userEntity.setUserName(orderRequestDto.getUserName());
		}
		return userEntity;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.OrderService.Service.OrderManagerIF#viewOrder(long)
	 */
	@Override
	@Transactional
	public UserEntity viewOrder(long userid) throws ServiceException{
		UserEntity userEntity = null;
		try {
			userEntity = dbManager.findUserByUserId(userid);
		} catch (Exception e) {
			log.info("Error occurred while fetching user data from DB");
		}
		return userEntity;
	}

	@Override
	@Transactional
	public String updateOrder(OrderUpdateDto orderUpdateDto) throws Exception{
		String status = null;
		orderUpdateDto.getItems().getMenuId();

		UserEntity userEntity = null;
		try {
			userEntity = dbManager.findUserByUserId(orderUpdateDto.getUserId());
		} catch (Exception e) {
			log.info("Error occurred while fetching user data from DB");
		}
		Optional<OrderEntity> findOrderDetails = userEntity.getOrderEntity().stream()
				.filter(oe -> oe.getMenuId() == orderUpdateDto.getItems().getMenuId()
						&& oe.getOrderId() == orderUpdateDto.getOrderId())
				.findFirst();
		
		if(findOrderDetails.isPresent()){
			int currentQuantity = findOrderDetails.get().getQuantity();
			switch (orderUpdateDto.getOperation()) {
			case "addQuantity":
				findOrderDetails.get().setQuantity(currentQuantity + orderUpdateDto.getItems().getQuantity());
				findOrderDetails.get()
						.setTotalPrice(findOrderDetails.get().getPrice() * findOrderDetails.get().getQuantity());
				status = "quantity added succesfully";
				break;
			case "removeQuantity":
				findOrderDetails.get().setQuantity(currentQuantity - orderUpdateDto.getItems().getQuantity());
				findOrderDetails.get()
						.setTotalPrice(findOrderDetails.get().getPrice() * findOrderDetails.get().getQuantity());
				status = "quantity removed succesfully";
				break;
			default:
				break;

			}
		}else{
			throw new Exception("updation not posible as You don't have active order with order id : "+ orderUpdateDto.getOrderId());
		}
		

		int totalPriceToBePaid = 0;
		if (!CollectionUtils.isEmpty(userEntity.getOrderEntity())) {
			for (OrderEntity order : userEntity.getOrderEntity()) {
				totalPriceToBePaid = totalPriceToBePaid + order.getTotalPrice();
			}
		} else {
			totalPriceToBePaid = userEntity.getTotalPriceToBePaid();
		}

		userEntity.setTotalPriceToBePaid(totalPriceToBePaid);
		updateUserDetaisToDB(userEntity);

		return status;
	}

	@Override
	@Transactional
	public String cancelOrder(long userid) throws Exception{
		UserEntity userEntity = dbManager.findUserByUserId(userid);

		userEntity.setItemOrdred("No");
		userEntity.setTotalPriceToBePaid(0);
		
		deletingOrderFromDB(userEntity);
		updateUserDetaisToDB(userEntity);
		return "Your order has ben cancelled";
	}

	private void updateUserDetaisToDB(UserEntity userEntity) {
		try {
			dbManager.updateUserDetails(userEntity);
		} catch (Exception e) {
			log.info("Error occurred while saving user data into DB");
		}
	}

	private void deletingOrderFromDB(UserEntity userEntity) throws Exception {
		if (!CollectionUtils.isEmpty(userEntity.getOrderEntity())) {

			for (OrderEntity oe : userEntity.getOrderEntity()) {
				try {
					dbManager.deleteByPOrderId(oe.getOrderId());
				} catch (Exception e) {
					log.info("Error occurred while deleting order data from DB");
				}
			}
		} else {
			throw new Exception("User doesn't have any active order");
		}
	}

}
