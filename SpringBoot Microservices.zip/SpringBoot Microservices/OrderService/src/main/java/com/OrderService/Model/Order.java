package com.OrderService.Model;

import com.fasterxml.jackson.annotation.JsonProperty;


public class Order {
	
	@JsonProperty("Menu id")
	private Long menId;
	
	@JsonProperty("Status")
	private String status;


	public Long getMenId() {
		return menId;
	}

	public void setMenId(Long menId) {
		this.menId = menId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
	

}
