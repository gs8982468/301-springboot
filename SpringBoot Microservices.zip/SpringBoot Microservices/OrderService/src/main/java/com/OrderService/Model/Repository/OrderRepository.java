package com.OrderService.Model.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.OrderService.DAO.OrderEntity;
@Repository
public interface OrderRepository extends JpaRepository<OrderEntity, Long> {

	@Modifying
	@Query(value = "Delete ORDERS where ORDER_ID=?", nativeQuery=true)
	public void deleteOrder(long orderId);
	
	/*@Modifying
	@Query(value = "Delete CART_PRODUCT where CART_ID= ?1 and PRODUCT_ID=?2", nativeQuery=true)
	public void deleteProductFromUserCart(long cartId, long productId);*/

	

}
