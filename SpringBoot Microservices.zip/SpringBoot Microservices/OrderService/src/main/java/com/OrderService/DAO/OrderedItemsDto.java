package com.OrderService.DAO;

//@Getter @Setter @NoArgsConstructor
public class OrderedItemsDto {
	
	private long restaurantId;
	private long menuId;
	private int quantity;

	
	
	public long getRestaurantId() {
		return restaurantId;
	}
	public void setRestaurantId(long restaurantId) {
		this.restaurantId = restaurantId;
	}
	public long getMenuId() {
		return menuId;
	}
	public void setMenuId(long menuId) {
		this.menuId = menuId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	


}
