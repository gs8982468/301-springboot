package com.OrderService.Service;

import org.springframework.stereotype.Component;

import com.OrderService.DAO.UserEntity;
@Component
public interface DBManagementServiceIF {

	

	public UserEntity findUserByUserId(long userId);

	public void updateUserDetails(UserEntity userEntity);

	
	public void deleteByPOrderId(long productId) ;
	
}
