package com.OrderService.Model.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.OrderService.DAO.UserEntity;

@Repository
public interface UserRepository extends JpaRepository<UserEntity, Long> {
	

	@Query(value = "select * from USERS  where USER_ID= ?", nativeQuery=true)
	public UserEntity findUserByUserId(long userId);
	

}
