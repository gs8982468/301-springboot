package com.OrderService.Model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;


public class RestaurantDetailsResponseEntity {
	

	@JsonProperty("Restaurent Id")
	private Long id;
	
	
	@JsonProperty("Restaurent Name")
	private String name;
	

	@JsonProperty("Location")
	private String location;
	

	@JsonProperty("Cuisine")
	private String cuisine;
	
	

	@JsonProperty("Budget")
	private String budget;
	

	@JsonProperty("Rating")
	private int rating;
	
	
	@JsonProperty("Menu Item")
	private List<MenuItemDetailsResponseEntity> menuItemDetails;

	public RestaurantDetailsResponseEntity(String name, String location, String cuisine, String budget, int rating, List<MenuItemDetailsResponseEntity> menuItemEntity) {
		super();
		this.name = name;
		this.location = location;
		this.cuisine = cuisine;
		this.budget = budget;
		this.rating = rating;
		this.menuItemDetails = menuItemEntity;
	}
	
	public List<MenuItemDetailsResponseEntity> getMenuDetails() {
		return menuItemDetails;
	}

	public void setMenuDetails(List<MenuItemDetailsResponseEntity> menuItemEntity) {
		this.menuItemDetails = menuItemEntity;
	}

	public RestaurantDetailsResponseEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Restaurant [id=" + id + ", name=" + name + ", location=" + location + ", cuisine=" + cuisine
				+ ", budget=" + budget + ", rating=" + rating + ", Menu_Item = "+ menuItemDetails + "]";
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getCuisine() {
		return cuisine;
	}

	public void setCuisine(String cuisine) {
		this.cuisine = cuisine;
	}

	public String getBudget() {
		return budget;
	}

	public void setBudget(String budget) {
		this.budget = budget;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}
	
	
}
