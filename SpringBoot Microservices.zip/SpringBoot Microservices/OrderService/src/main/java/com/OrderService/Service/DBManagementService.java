package com.OrderService.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.OrderService.DAO.UserEntity;
import com.OrderService.Model.Repository.OrderRepository;
import com.OrderService.Model.Repository.UserRepository;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class DBManagementService implements DBManagementServiceIF{
	

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private OrderRepository orderRepo;

	

	@Override
	public UserEntity findUserByUserId(long userId) {
		return userRepo.findUserByUserId(userId);
	}
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void updateUserDetails(UserEntity userEntity) {
		userRepo.save(userEntity);
	}
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void deleteByPOrderId(long productId) {
		orderRepo.deleteOrder(productId);
	}
	

}
