package com.OrderService.DAO;

import java.util.List;

public class OrderUpdateDto {
	
	private Long userId;
	private Long orderId;

	private String operation;
	private OrderedItemsDto items;
	
	
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	public OrderedItemsDto getItems() {
		return items;
	}
	public void setItems(OrderedItemsDto items) {
		this.items = items;
	}
	
	
	
	

}
