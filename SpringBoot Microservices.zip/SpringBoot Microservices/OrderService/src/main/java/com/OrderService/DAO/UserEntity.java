package com.OrderService.DAO;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name= "USERS")
public class UserEntity {
	
	
	@Id
	/*@GeneratedValue (strategy = GenerationType.IDENTITY)*/
	@Column(name = "USER_ID")
	@JsonProperty("User Id")
	private Long userId;
	
	@Column(name = "USER_NAME")
	@JsonProperty("User name")
	private String userName;
	
	@Column(name = "ITEM_ORDERED")
	@JsonProperty("Any Item Orderd")
	private String itemOrdred;
	
	@Column(name = "TOTAL_PRICE_TO_BE_PAID")
	@JsonProperty("Total price to be paid by user")
	private int totalPriceToBePaid;
	
	
	@OneToMany(cascade={CascadeType.PERSIST, CascadeType.MERGE},mappedBy="user", fetch=FetchType.LAZY)
	@JsonProperty("Order Details")
	private List<OrderEntity> orderEntity;
	
	public String getItemOrdred() {
		return itemOrdred;
	}


	public void setItemOrdred(String itemOrdred) {
		this.itemOrdred = itemOrdred;
	}


	public List<OrderEntity> getOrderEntity() {
		return orderEntity;
	}


	public void setOrderEntity(List<OrderEntity> orderEntity) {
		this.orderEntity = orderEntity;
	}


	public Long getUserId() {
		return userId;
	}


	public void setUserId(Long userId) {
		this.userId = userId;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public int getTotalPriceToBePaid() {
		return totalPriceToBePaid;
	}


	public void setTotalPriceToBePaid(int totalPriceToBePaid) {
		this.totalPriceToBePaid = totalPriceToBePaid;
	}




	

}
