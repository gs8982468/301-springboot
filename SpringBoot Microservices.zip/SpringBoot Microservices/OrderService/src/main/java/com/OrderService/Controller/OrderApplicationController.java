package com.OrderService.Controller;

import java.util.List;

import org.hibernate.service.spi.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.OrderService.DAO.OrderRequestDto;
import com.OrderService.DAO.OrderUpdateDto;
import com.OrderService.DAO.UserEntity;
import com.OrderService.Exception.OrderException;
import com.OrderService.Model.Order;
import com.OrderService.Service.OrderManagerIF;

@RestController
public class OrderApplicationController {
	
	@Autowired
	private OrderManagerIF orderManagerIf;

	@RequestMapping(value="/home", method= RequestMethod.GET)
	public String check(){
		return "Hi User, Welcome to order service";
	}

	/**
	 * This method is used to place an order
	 * @param orderRequestDto OrderRequestDto
	 * @return ResponseEntity<List<Order>> 
	 * @throws OrderException
	 */
	@RequestMapping(value="/order", method= RequestMethod.POST)
	public ResponseEntity<List<Order>> placeOrder(@RequestBody OrderRequestDto orderRequestDto) throws OrderException{
		
		List<Order> orderDetails=  orderManagerIf.placeOrder(orderRequestDto);
		
		return ResponseEntity
				.status(HttpStatus.OK)
				.body(orderDetails);
	}
	
	/**
	 * This  method is used to view the order
	 * @param userid long
	 * @return
	 */
	@RequestMapping(value="/order/view/{userid}", method= RequestMethod.GET)
	public ResponseEntity<UserEntity> fetchRestetails(@PathVariable long userid) throws ServiceException{ 
		UserEntity userEntity=  orderManagerIf.viewOrder(userid);
		
		return ResponseEntity
				.status(HttpStatus.OK)
				.body(userEntity);
	}
	
	/**
	 * This  method is used to update the order
	 * @param orderUpdateDto
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/order/update", method= RequestMethod.POST)
	public ResponseEntity<String> updateOrder(@RequestBody OrderUpdateDto orderUpdateDto) throws Exception{
		String status=  orderManagerIf.updateOrder(orderUpdateDto);
		
		return ResponseEntity
				.status(HttpStatus.OK)
				.body(status);
	}
	
	@RequestMapping(value="/order/cancel/{userid}", method= RequestMethod.GET)
	public ResponseEntity<String> cancelOrder(@PathVariable long userid) throws Exception{
		String status=  orderManagerIf.cancelOrder(userid);
		
		return ResponseEntity
				.status(HttpStatus.OK)
				.body(status);
	}
	
	

}
